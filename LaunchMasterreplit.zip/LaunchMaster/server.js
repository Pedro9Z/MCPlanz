const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const yaml = require('js-yaml');
const { exec, spawn } = require('child_process');
const os = require('os');

// Import services
const SystemDetection = require('./src/services/systemDetection');
const WorkflowEngine = require('./src/services/workflowEngine');
const YamlParser = require('./src/services/yamlParser');

const app = express();
const PORT = 5000;

// Middleware
app.use(express.json());
app.use(express.static('public'));
app.use('/src', express.static('src'));

// Initialize services
const systemDetection = new SystemDetection();
const workflowEngine = new WorkflowEngine();
const yamlParser = new YamlParser();

// API Routes
app.get('/api/system-info', async (req, res) => {
    try {
        const systemInfo = await systemDetection.detectSystem();
        res.json({ success: true, data: systemInfo });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.get('/api/workflows', async (req, res) => {
    try {
        const workflowsDir = path.join(__dirname, 'workflows');
        const files = await fs.readdir(workflowsDir);
        const workflows = [];

        for (const file of files) {
            if (file.endsWith('.yaml') || file.endsWith('.yml')) {
                const filePath = path.join(workflowsDir, file);
                const content = await fs.readFile(filePath, 'utf8');
                const workflow = yamlParser.parse(content);
                workflow.filename = file;
                workflows.push(workflow);
            }
        }

        res.json({ success: true, data: workflows });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.post('/api/workflows', async (req, res) => {
    try {
        const workflow = req.body;
        const workflowsDir = path.join(__dirname, 'workflows');
        const filename = workflow.filename || `${workflow.name.replace(/\s+/g, '-').toLowerCase()}.yaml`;
        const filePath = path.join(workflowsDir, filename);
        
        const yamlContent = yamlParser.stringify(workflow);
        await fs.writeFile(filePath, yamlContent, 'utf8');
        
        res.json({ success: true, data: { filename } });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.delete('/api/workflows/:filename', async (req, res) => {
    try {
        const filename = req.params.filename;
        const filePath = path.join(__dirname, 'workflows', filename);
        await fs.unlink(filePath);
        res.json({ success: true });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.post('/api/execute', async (req, res) => {
    try {
        const workflow = req.body;
        const executionId = workflowEngine.execute(workflow);
        res.json({ success: true, data: { executionId } });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.post('/api/stop/:executionId', async (req, res) => {
    try {
        const executionId = req.params.executionId;
        await workflowEngine.stop(executionId);
        res.json({ success: true });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.get('/api/status/:executionId', async (req, res) => {
    try {
        const executionId = req.params.executionId;
        const status = workflowEngine.getStatus(executionId);
        res.json({ success: true, data: status });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.post('/api/import', async (req, res) => {
    try {
        const { content } = req.body;
        const workflow = yamlParser.parse(content);
        res.json({ success: true, data: workflow });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.post('/api/export', async (req, res) => {
    try {
        const workflow = req.body;
        const yamlContent = yamlParser.stringify(workflow);
        res.json({ success: true, data: yamlContent });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

// WebSocket for real-time updates
const http = require('http');
const socketIo = require('socket.io');

const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Forward workflow engine events to WebSocket clients
workflowEngine.on('execution-update', (data) => {
    io.emit('execution-update', data);
});

io.on('connection', (socket) => {
    console.log('Client connected');
    
    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });
});

// Serve main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
server.listen(PORT, '0.0.0.0', () => {
    console.log(`App Launcher server running on http://0.0.0.0:${PORT}`);
});

module.exports = app;