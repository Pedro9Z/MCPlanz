#!/usr/bin/env python3

import os
import time
import subprocess
from PIL import Image, ImageDraw, ImageFont
import io

def create_demo_frames():
    """Crea frames de demostración para el GIF"""
    
    # Configuración
    width, height = 800, 600
    bg_color = (30, 30, 30)  # Fondo oscuro
    text_color = (255, 255, 255)  # Texto blanco
    accent_color = (0, 150, 255)  # Azul para acentos
    
    frames = []
    
    try:
        # Fuente por defecto
        font_title = ImageFont.load_default()
        font_text = ImageFont.load_default()
    except:
        font_title = None
        font_text = None
    
    # Frame 1: Título
    img = Image.new('RGB', (width, height), bg_color)
    draw = ImageDraw.Draw(img)
    
    # Título
    title = "App Launcher"
    subtitle = "Lanzador de aplicaciones multiplataforma"
    
    # Centrar título
    if font_title:
        bbox = draw.textbbox((0, 0), title, font=font_title)
        title_width = bbox[2] - bbox[0]
        title_x = (width - title_width) // 2
    else:
        title_x = width // 2 - len(title) * 4
    
    draw.text((title_x, height//2 - 50), title, fill=accent_color, font=font_title)
    
    # Subtítulo
    if font_text:
        bbox = draw.textbbox((0, 0), subtitle, font=font_text)
        subtitle_width = bbox[2] - bbox[0]
        subtitle_x = (width - subtitle_width) // 2
    else:
        subtitle_x = width // 2 - len(subtitle) * 3
    
    draw.text((subtitle_x, height//2 + 20), subtitle, fill=text_color, font=font_text)
    
    frames.append(img)
    
    # Frame 2: Características
    img = Image.new('RGB', (width, height), bg_color)
    draw = ImageDraw.Draw(img)
    
    features = [
        "✓ Ejecución nativa y en contenedores",
        "✓ Editor visual de flujos de trabajo",
        "✓ Monitoreo en tiempo real",
        "✓ Configuración YAML",
        "✓ Detección automática del sistema"
    ]
    
    draw.text((50, 50), "Características principales:", fill=accent_color, font=font_title)
    
    for i, feature in enumerate(features):
        draw.text((70, 100 + i * 40), feature, fill=text_color, font=font_text)
    
    frames.append(img)
    
    # Frame 3: Interfaz simulada
    img = Image.new('RGB', (width, height), bg_color)
    draw = ImageDraw.Draw(img)
    
    # Simular interfaz web
    # Header
    draw.rectangle([0, 0, width, 60], fill=(50, 50, 50))
    draw.text((20, 20), "App Launcher - Workflows", fill=text_color, font=font_title)
    
    # Navegación
    draw.rectangle([20, 80, 200, 120], fill=accent_color)
    draw.text((30, 90), "Workflows", fill=text_color, font=font_text)
    
    draw.rectangle([220, 80, 320, 120], fill=(80, 80, 80))
    draw.text((230, 90), "Monitor", fill=text_color, font=font_text)
    
    # Lista de workflows
    workflows = [
        "WebDev-Native",
        "WebDev-Container", 
        "Creative Suite"
    ]
    
    for i, workflow in enumerate(workflows):
        y = 150 + i * 80
        # Card
        draw.rectangle([50, y, width-50, y+60], fill=(60, 60, 60))
        draw.text((70, y+10), workflow, fill=text_color, font=font_text)
        draw.text((70, y+30), f"Modo: {'Container' if 'Container' in workflow else 'Native'}", fill=(150, 150, 150), font=font_text)
        
        # Botón Launch
        draw.rectangle([width-150, y+15, width-70, y+45], fill=(0, 200, 0))
        draw.text((width-130, y+25), "Launch", fill=text_color, font=font_text)
    
    frames.append(img)
    
    # Frame 4: Ejecución
    img = Image.new('RGB', (width, height), bg_color)
    draw = ImageDraw.Draw(img)
    
    # Header
    draw.rectangle([0, 0, width, 60], fill=(50, 50, 50))
    draw.text((20, 20), "App Launcher - Monitor", fill=text_color, font=font_title)
    
    # Log simulado
    draw.rectangle([20, 80, width-20, height-20], fill=(20, 20, 20))
    
    log_entries = [
        "[INFO] Iniciando WebDev-Native...",
        "[INFO] Ejecutando paso 1: Instalar dependencias",
        "[INFO] npm install",
        "[INFO] Dependencias instaladas exitosamente",
        "[INFO] Ejecutando paso 2: Iniciar servidor",
        "[INFO] npm start",
        "[INFO] Servidor iniciado en puerto 3000",
        "[SUCCESS] Workflow completado exitosamente"
    ]
    
    for i, entry in enumerate(log_entries):
        color = (0, 255, 0) if "SUCCESS" in entry else (0, 150, 255) if "INFO" in entry else text_color
        draw.text((40, 100 + i * 25), entry, fill=color, font=font_text)
    
    frames.append(img)
    
    return frames

def create_demo_gif():
    """Crea el GIF demostrativo"""
    
    print("Creando frames de demostración...")
    frames = create_demo_frames()
    
    # Duplicar frames para mayor duración
    extended_frames = []
    for frame in frames:
        for _ in range(30):  # 30 frames por segundo
            extended_frames.append(frame.copy())
    
    # Guardar como GIF
    print("Guardando GIF...")
    extended_frames[0].save(
        'demo.gif',
        save_all=True,
        append_images=extended_frames[1:],
        duration=100,  # 100ms por frame
        loop=0
    )
    
    print("GIF creado exitosamente: demo.gif")

if __name__ == "__main__":
    create_demo_gif()