# App Launcher

Una aplicación multiplataforma para lanzar aplicaciones locales con ejecución de un clic, compatible con comandos nativos y flujos de trabajo en contenedores.

![App Launcher Demo](demo.gif)

## 🚀 Características

- 🖥️ **Multiplataforma**: Funciona en Windows, macOS y Linux
- ⚡ **Modo Nativo**: Ejecuta comandos y aplicaciones locales directamente
- 🐳 **Modo Contenedor**: Ejecuta flujos de trabajo en Docker o Podman
- 🎯 **Lanzamiento de un clic**: Ejecuta flujos complejos con un solo clic
- 📝 **Configuración YAML**: Definiciones de flujo legibles
- 🔄 **Monitoreo en tiempo real**: Logs de ejecución y verificaciones de salud
- 🎨 **Editor visual**: Creación de flujos con arrastrar y soltar
- 📊 **Detección del sistema**: Detección automática de SO y motores de contenedores
- 🛡️ **Seguridad**: Sin contraseñas en texto plano, contenedores no privilegiados por defecto

## 📋 Requisitos del Sistema

- Node.js 16+ y npm
- Para flujos en contenedores: Docker o Podman (opcional)

## 🛠️ Instalación

### Opción 1: Instalación Rápida

#### Windows
```cmd
# Descarga y ejecuta el instalador
install.bat
```

#### macOS/Linux
```bash
# Descarga y ejecuta el instalador
chmod +x install.sh
./install.sh
```

### Opción 2: Instalación Manual

1. **Clona el repositorio:**
```bash
git clone https://github.com/usuario/app-launcher.git
cd app-launcher
```

2. **Instala las dependencias:**
```bash
npm install
```

3. **Inicia la aplicación:**
```bash
npm start
```

La aplicación se abrirá en tu navegador en `http://localhost:5000`

## 🎯 Inicio Rápido

### 1. Ejecutar un Flujo de Trabajo Demo

La aplicación incluye tres flujos de trabajo de demostración:

- **WebDev-Native**: Configura un entorno de desarrollo web usando comandos nativos
- **WebDev-Container**: Ejecuta un servidor web en un contenedor Docker
- **Creative Suite**: Lanza aplicaciones creativas como GIMP y Inkscape

1. Abre la aplicación en tu navegador
2. Selecciona un flujo de trabajo de la lista
3. Haz clic en "Launch" para ejecutarlo
4. Observa los logs en tiempo real en la pestaña "Monitor"

### 2. Crear tu Primer Flujo de Trabajo

1. Haz clic en "Create New Workflow"
2. Completa la información básica:
   - **Nombre**: "Mi Primer Flujo"
   - **Descripción**: "Descripción del flujo"
   - **Modo**: Native o Container
3. Añade pasos:
   - Haz clic en "Add Step"
   - Introduce nombre y comando
   - Guarda el paso
4. Guarda el flujo de trabajo
5. Ejecuta desde la lista principal

## 📁 Estructura del Proyecto

```
app-launcher/
├── public/                 # Archivos estáticos web
├── src/
│   ├── components/        # Componentes React
│   ├── services/         # Servicios backend
│   └── utils/           # Utilidades
├── workflows/           # Flujos de trabajo YAML
├── install.bat         # Instalador Windows
├── install.sh          # Instalador Unix/Linux
├── server.js           # Servidor Express
└── package.json        # Dependencias del proyecto
```

## 🔧 Configuración Avanzada

### Formato YAML del Flujo de Trabajo

```yaml
name: "Mi Flujo de Trabajo"
description: "Descripción del flujo"
mode: "native"  # o "container"
steps:
  - name: "Paso 1"
    command: "echo 'Hola mundo'"
    description: "Saludo inicial"
    workdir: "."
    timeout: 30
  - name: "Paso 2"
    command: "npm install"
    description: "Instalar dependencias"
    workdir: "./mi-proyecto"
    timeout: 300
```

### Configuración de Contenedores

```yaml
name: "Flujo en Contenedor"
description: "Ejecutar en Docker"
mode: "container"
image: "node:18-alpine"
ports:
  - "3000:3000"
  - "8080:8080"
volumes:
  - "./:/workspace"
  - "/tmp:/tmp"
environment:
  NODE_ENV: "development"
  PORT: "3000"
steps:
  - name: "Instalar"
    command: "npm install"
    workdir: "/workspace"
  - name: "Iniciar"
    command: "npm start"
    workdir: "/workspace"
```

## 🚀 Funcionalidades Principales

### Gestión de Flujos de Trabajo
- **Crear**: Editor visual con formularios intuitivos
- **Editar**: Modificar flujos existentes
- **Ejecutar**: Lanzamiento con un clic
- **Importar/Exportar**: Archivos YAML para compartir
- **Eliminar**: Gestión completa del ciclo de vida

### Monitoreo de Ejecución
- **Logs en tiempo real**: Ver salida de comandos en vivo
- **Estado de ejecución**: Seguimiento del progreso
- **Control de ejecución**: Detener procesos en ejecución
- **Historial**: Registro de ejecuciones pasadas

### Detección del Sistema
- **SO automático**: Detección de Windows, macOS, Linux
- **Motores de contenedores**: Soporte para Docker y Podman
- **Dependencias**: Verificación de herramientas necesarias
- **Recursos**: Monitoreo del sistema

## 🐳 Uso con Contenedores

### Configurar Docker

1. **Instala Docker Desktop** (Windows/macOS) o Docker Engine (Linux)
2. **Verifica la instalación:**
```bash
docker --version
```
3. **Ejecuta tu primer flujo en contenedor** desde la aplicación

### Configurar Podman (Alternativa)

1. **Instala Podman:**
```bash
# En Linux (Ubuntu/Debian)
sudo apt install podman

# En macOS
brew install podman
```
2. **Verifica la instalación:**
```bash
podman --version
```

## 🛠️ Desarrollo

### Ejecutar en Modo Desarrollo

```bash
# Instalar dependencias
npm install

# Iniciar servidor de desarrollo
npm run dev

# La aplicación se abrirá en http://localhost:5000
```

### Estructura de Servicios

- **SystemDetection**: Detecta capacidades del sistema
- **WorkflowEngine**: Ejecuta flujos de trabajo
- **ContainerManager**: Gestiona contenedores Docker/Podman
- **YamlParser**: Procesa archivos de configuración

### API REST

La aplicación expone una API REST para integración:

```
GET    /api/system-info     # Información del sistema
GET    /api/workflows       # Lista de flujos de trabajo
POST   /api/workflows       # Crear/actualizar flujo
DELETE /api/workflows/:id   # Eliminar flujo
POST   /api/execute         # Ejecutar flujo
POST   /api/stop/:id        # Detener ejecución
GET    /api/status/:id      # Estado de ejecución
```

## 🔒 Seguridad

### Mejores Prácticas
- **Sin contraseñas en texto plano**: Usa variables de entorno
- **Contenedores no privilegiados**: Ejecución segura por defecto
- **Validación de entrada**: Todos los comandos son validados
- **Aislamiento**: Cada flujo se ejecuta en su propio contexto

### Configuración de Seguridad
```yaml
# Ejemplo de configuración segura
environment:
  DB_PASSWORD: "${DB_PASSWORD}"  # Variable de entorno
  API_KEY: "${API_KEY}"         # No hardcodeado
```

## 🐛 Solución de Problemas

### Problemas Comunes

**Error: "Docker not found"**
```bash
# Verifica que Docker esté instalado e iniciado
docker --version
sudo systemctl start docker  # En Linux
```

**Error: "Port already in use"**
```bash
# Cambia el puerto en package.json o detén el proceso
lsof -i :5000
kill -9 <PID>
```

**Error: "Permission denied"**
```bash
# En Linux/macOS, asegúrate de tener permisos
sudo chmod +x install.sh
```

### Logs de Depuración

Los logs se guardan en:
- **Windows**: `%USERPROFILE%\.app-launcher\logs`
- **macOS/Linux**: `~/.app-launcher/logs`

## 📚 Recursos Adicionales

### Documentación
- [Guía de usuario completa](docs/user-guide.md)
- [Referencia de API](docs/api-reference.md)
- [Ejemplos de flujos](workflows/examples/)

### Comunidad
- [Reporte de errores](https://github.com/usuario/app-launcher/issues)
- [Solicitud de características](https://github.com/usuario/app-launcher/issues/new)
- [Contribuir](CONTRIBUTING.md)

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo [LICENSE](LICENSE) para más detalles.

## 🤝 Contribuir

¡Las contribuciones son bienvenidas! Por favor:

1. Haz fork del repositorio
2. Crea una rama para tu característica
3. Realiza tus cambios
4. Añade pruebas si es necesario
5. Envía un pull request

## 📞 Soporte

Si necesitas ayuda:
- 📧 Email: support@app-launcher.com
- 💬 Discord: [Servidor de la comunidad](https://discord.gg/app-launcher)
- 📖 Wiki: [Documentación completa](https://github.com/usuario/app-launcher/wiki)

---

**¡Gracias por usar App Launcher!** 🎉
