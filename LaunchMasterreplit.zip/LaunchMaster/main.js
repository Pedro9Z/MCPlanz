const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs').promises;
const SystemDetection = require('./src/services/systemDetection');
const WorkflowEngine = require('./src/services/workflowEngine');
const YamlParser = require('./src/services/yamlParser');

class AppLauncher {
    constructor() {
        this.mainWindow = null;
        this.systemDetection = new SystemDetection();
        this.workflowEngine = new WorkflowEngine();
        this.yamlParser = new YamlParser();
        this.setupIPC();
    }

    async createWindow() {
        this.mainWindow = new BrowserWindow({
            width: 1200,
            height: 800,
            webPreferences: {
                nodeIntegration: false,
                contextIsolation: true,
                preload: path.join(__dirname, 'preload.js')
            },
            icon: path.join(__dirname, 'assets', 'icon.png'),
            titleBarStyle: 'default',
            show: false
        });

        // Load the React app
        await this.mainWindow.loadFile('public/index.html');

        this.mainWindow.once('ready-to-show', () => {
            this.mainWindow.show();
        });

        if (process.env.NODE_ENV === 'development') {
            this.mainWindow.webContents.openDevTools();
        }
    }

    setupIPC() {
        // System detection
        ipcMain.handle('get-system-info', async () => {
            try {
                const systemInfo = await this.systemDetection.detectSystem();
                return { success: true, data: systemInfo };
            } catch (error) {
                return { success: false, error: error.message };
            }
        });

        // Workflow management
        ipcMain.handle('load-workflows', async () => {
            try {
                const workflowsDir = path.join(__dirname, 'workflows');
                const files = await fs.readdir(workflowsDir);
                const workflows = [];

                for (const file of files) {
                    if (file.endsWith('.yaml') || file.endsWith('.yml')) {
                        const filePath = path.join(workflowsDir, file);
                        const content = await fs.readFile(filePath, 'utf8');
                        const workflow = this.yamlParser.parse(content);
                        workflow.filename = file;
                        workflows.push(workflow);
                    }
                }

                return { success: true, data: workflows };
            } catch (error) {
                return { success: false, error: error.message };
            }
        });

        ipcMain.handle('save-workflow', async (event, workflow) => {
            try {
                const workflowsDir = path.join(__dirname, 'workflows');
                const filename = workflow.filename || `${workflow.name.replace(/\s+/g, '-').toLowerCase()}.yaml`;
                const filePath = path.join(workflowsDir, filename);
                
                const yamlContent = this.yamlParser.stringify(workflow);
                await fs.writeFile(filePath, yamlContent, 'utf8');
                
                return { success: true, data: { filename } };
            } catch (error) {
                return { success: false, error: error.message };
            }
        });

        ipcMain.handle('delete-workflow', async (event, filename) => {
            try {
                const filePath = path.join(__dirname, 'workflows', filename);
                await fs.unlink(filePath);
                return { success: true };
            } catch (error) {
                return { success: false, error: error.message };
            }
        });

        // Workflow execution
        ipcMain.handle('execute-workflow', async (event, workflow) => {
            try {
                const executionId = this.workflowEngine.execute(workflow);
                return { success: true, data: { executionId } };
            } catch (error) {
                return { success: false, error: error.message };
            }
        });

        ipcMain.handle('stop-workflow', async (event, executionId) => {
            try {
                await this.workflowEngine.stop(executionId);
                return { success: true };
            } catch (error) {
                return { success: false, error: error.message };
            }
        });

        ipcMain.handle('get-execution-status', async (event, executionId) => {
            try {
                const status = this.workflowEngine.getStatus(executionId);
                return { success: true, data: status };
            } catch (error) {
                return { success: false, error: error.message };
            }
        });

        // File operations
        ipcMain.handle('import-workflow', async () => {
            try {
                const result = await dialog.showOpenDialog(this.mainWindow, {
                    properties: ['openFile'],
                    filters: [
                        { name: 'YAML Files', extensions: ['yaml', 'yml'] }
                    ]
                });

                if (!result.canceled && result.filePaths.length > 0) {
                    const content = await fs.readFile(result.filePaths[0], 'utf8');
                    const workflow = this.yamlParser.parse(content);
                    return { success: true, data: workflow };
                }

                return { success: false, error: 'Import cancelled' };
            } catch (error) {
                return { success: false, error: error.message };
            }
        });

        ipcMain.handle('export-workflow', async (event, workflow) => {
            try {
                const result = await dialog.showSaveDialog(this.mainWindow, {
                    defaultPath: `${workflow.name.replace(/\s+/g, '-').toLowerCase()}.yaml`,
                    filters: [
                        { name: 'YAML Files', extensions: ['yaml'] }
                    ]
                });

                if (!result.canceled) {
                    const yamlContent = this.yamlParser.stringify(workflow);
                    await fs.writeFile(result.filePath, yamlContent, 'utf8');
                    return { success: true };
                }

                return { success: false, error: 'Export cancelled' };
            } catch (error) {
                return { success: false, error: error.message };
            }
        });
    }
}

const appLauncher = new AppLauncher();

app.whenReady().then(async () => {
    await appLauncher.createWindow();

    app.on('activate', async () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            await appLauncher.createWindow();
        }
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});
