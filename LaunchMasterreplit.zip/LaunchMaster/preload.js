const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
    // System operations
    getSystemInfo: () => ipcRenderer.invoke('get-system-info'),
    
    // Workflow management
    loadWorkflows: () => ipcRenderer.invoke('load-workflows'),
    saveWorkflow: (workflow) => ipcRenderer.invoke('save-workflow', workflow),
    deleteWorkflow: (filename) => ipcRenderer.invoke('delete-workflow', filename),
    
    // Workflow execution
    executeWorkflow: (workflow) => ipcRenderer.invoke('execute-workflow', workflow),
    stopWorkflow: (executionId) => ipcRenderer.invoke('stop-workflow', executionId),
    getExecutionStatus: (executionId) => ipcRenderer.invoke('get-execution-status', executionId),
    
    // File operations
    importWorkflow: () => ipcRenderer.invoke('import-workflow'),
    exportWorkflow: (workflow) => ipcRenderer.invoke('export-workflow', workflow),
    
    // Event listeners
    onWorkflowUpdate: (callback) => ipcRenderer.on('workflow-update', callback),
    onExecutionUpdate: (callback) => ipcRenderer.on('execution-update', callback),
    onSystemUpdate: (callback) => ipcRenderer.on('system-update', callback)
});
