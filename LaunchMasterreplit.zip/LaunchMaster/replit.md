# App Launcher - Aplicación Web

## Overview

App Launcher es una aplicación web multiplataforma construida con Express.js y React que permite a los usuarios crear, gestionar y ejecutar flujos de trabajo con ejecución de un clic. La aplicación soporta tanto comandos nativos del sistema como flujos de trabajo en contenedores usando Docker o Podman.

**Estado actual**: Aplicación web completamente funcional ejecutándose en puerto 5000.

## User Preferences

Preferred communication style: Simple, everyday language in Spanish.

## System Architecture

### Frontend Architecture
- **Framework**: React 19 with functional components and hooks
- **UI Library**: Custom CSS with Font Awesome icons
- **Drag & Drop**: React DnD for workflow step reordering
- **State Management**: React useState and useEffect hooks
- **Renderer Process**: Isolated context with preload script for security

### Backend Architecture
- **Runtime**: Express.js server with Node.js
- **API Communication**: RESTful API endpoints for client-server communication
- **WebSocket**: Socket.io for real-time updates and monitoring
- **Service Layer**: Modular services for system detection, workflow execution, and container management
- **Event System**: EventEmitter-based architecture for real-time updates

### Web Application Structure
- **Server**: Express.js backend handling API requests and workflow execution
- **Client**: React-based frontend served as static files
- **Real-time Communication**: WebSocket connection for live updates

## Key Components

### Core Services
1. **SystemDetection**: Detects OS, container engines, and system capabilities
2. **WorkflowEngine**: Executes workflows in native or container mode with real-time monitoring
3. **ContainerManager**: Manages Docker/Podman container operations
4. **YamlParser**: Handles YAML workflow configuration parsing and validation

### UI Components
1. **App**: Main application container with view routing
2. **WorkflowList**: Grid view of workflows with search and filtering
3. **WorkflowEditor**: Drag-and-drop workflow creation and editing
4. **ExecutionMonitor**: Real-time execution tracking with logs
5. **SystemStatus**: System information and container engine status

### Utilities
1. **Logger**: Execution logging with file persistence
2. **HealthCheck**: Service health monitoring with retry logic

## Data Flow

### Workflow Execution Flow
1. User selects workflow from list
2. WorkflowEngine creates execution context
3. System executes steps sequentially (native commands or container operations)
4. Real-time logs and status updates sent to UI via IPC
5. Execution results stored and displayed

### Configuration Management
1. Workflows stored as YAML files in user's home directory
2. YamlParser validates and normalizes workflow definitions
3. SystemDetection caches system capabilities
4. Execution logs persisted to filesystem

### Web API Communication
- Express.js server exposes RESTful API endpoints
- React frontend communicates through fetch API calls
- WebSocket connection for real-time updates and monitoring

## External Dependencies

### Runtime Dependencies
- **Express.js**: Web server framework
- **Socket.io**: Real-time communication
- **React**: UI framework loaded via CDN
- **js-yaml**: YAML parsing and serialization

### System Dependencies
- **Node.js 16+**: Runtime environment
- **Docker/Podman**: Container engine (optional, for container workflows)
- **Operating System**: Cross-platform support (Windows, macOS, Linux)

### External Resources
- **Font Awesome**: Icon library (CDN)
- **Babel Standalone**: JSX transformation (CDN)
- **React Libraries**: Loaded via CDN for development
- **Socket.io Client**: Real-time communication library (CDN)

## Deployment Strategy

### Development Setup
- Standard Node.js project with npm dependencies
- Express.js server with static file serving
- Component-based React architecture with modular services

### Production Deployment
- Web-based deployment on any Node.js hosting platform
- Static file serving for React components
- RESTful API with WebSocket support for real-time features

### File System Structure
- Application code in project directory
- User data in `~/.app-launcher/` directory
- Workflows stored as individual YAML files
- Execution logs in dedicated logs directory

### Security Considerations
- Context isolation enabled in renderer process
- No node integration in renderer
- Secure IPC communication only
- Non-privileged containers by default
- No plain text password storage