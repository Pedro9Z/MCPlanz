const { exec } = require('child_process');
const { promisify } = require('util');

class HealthCheck {
    constructor() {
        this.execAsync = promisify(exec);
        this.checks = new Map();
    }

    async check(command, containerId = null, options = {}) {
        const {
            timeout = 10000,
            retries = 3,
            retryDelay = 1000
        } = options;

        for (let attempt = 1; attempt <= retries; attempt++) {
            try {
                const result = await this.executeHealthCheck(command, containerId, timeout);
                return result.success;
            } catch (error) {
                if (attempt === retries) {
                    throw error;
                }
                
                // Wait before retry
                await this.delay(retryDelay);
            }
        }

        return false;
    }

    async executeHealthCheck(command, containerId, timeout) {
        return new Promise((resolve, reject) => {
            let fullCommand;

            if (containerId) {
                // Execute command inside container
                fullCommand = `docker exec ${containerId} sh -c "${command}"`;
            } else {
                // Execute command on host
                fullCommand = command;
            }

            const child = exec(fullCommand, { timeout });

            child.on('exit', (code) => {
                resolve({
                    success: code === 0,
                    exitCode: code
                });
            });

            child.on('error', (error) => {
                reject(error);
            });
        });
    }

    // Common health check patterns
    httpCheck(url, options = {}) {
        const {
            method = 'GET',
            expectedStatus = 200,
            timeout = 5000
        } = options;

        let command;
        
        if (this.isCommandAvailable('curl')) {
            command = `curl -f --max-time ${Math.floor(timeout / 1000)} -X ${method} "${url}"`;
        } else if (this.isCommandAvailable('wget')) {
            command = `wget --timeout=${Math.floor(timeout / 1000)} --tries=1 -q -O- "${url}"`;
        } else {
            throw new Error('Neither curl nor wget is available for HTTP health checks');
        }

        return command;
    }

    tcpCheck(host, port, options = {}) {
        const { timeout = 5000 } = options;
        
        if (this.isCommandAvailable('nc')) {
            return `nc -z -w${Math.floor(timeout / 1000)} ${host} ${port}`;
        } else if (this.isCommandAvailable('telnet')) {
            return `echo | telnet ${host} ${port}`;
        } else {
            throw new Error('Neither nc nor telnet is available for TCP health checks');
        }
    }

    processCheck(processName) {
        const platform = require('os').platform();
        
        if (platform === 'win32') {
            return `tasklist /FI "IMAGENAME eq ${processName}" | find /I "${processName}"`;
        } else {
            return `pgrep -f "${processName}"`;
        }
    }

    fileCheck(filePath) {
        const platform = require('os').platform();
        
        if (platform === 'win32') {
            return `if exist "${filePath}" (exit 0) else (exit 1)`;
        } else {
            return `test -f "${filePath}"`;
        }
    }

    serviceCheck(serviceName) {
        const platform = require('os').platform();
        
        if (platform === 'win32') {
            return `sc query "${serviceName}" | find "RUNNING"`;
        } else if (platform === 'darwin') {
            return `launchctl list | grep "${serviceName}"`;
        } else {
            // Linux - try systemd first, then fallback to service command
            return `systemctl is-active "${serviceName}" || service "${serviceName}" status`;
        }
    }

    // Database health checks
    mysqlCheck(options = {}) {
        const {
            host = 'localhost',
            port = 3306,
            user = 'root',
            database = 'mysql'
        } = options;

        return `mysql -h ${host} -P ${port} -u ${user} -e "SELECT 1" ${database}`;
    }

    postgresCheck(options = {}) {
        const {
            host = 'localhost',
            port = 5432,
            user = 'postgres',
            database = 'postgres'
        } = options;

        return `pg_isready -h ${host} -p ${port} -U ${user} -d ${database}`;
    }

    redisCheck(options = {}) {
        const {
            host = 'localhost',
            port = 6379
        } = options;

        return `redis-cli -h ${host} -p ${port} ping`;
    }

    // Advanced health checks
    async multiCheck(checks, options = {}) {
        const {
            mode = 'all', // 'all' or 'any'
            timeout = 30000
        } = options;

        const results = await Promise.allSettled(
            checks.map(check => this.check(check.command, check.containerId, check.options))
        );

        if (mode === 'all') {
            return results.every(result => 
                result.status === 'fulfilled' && result.value === true
            );
        } else {
            return results.some(result => 
                result.status === 'fulfilled' && result.value === true
            );
        }
    }

    async periodicCheck(command, containerId, interval, callback) {
        const checkId = `${containerId || 'host'}_${Date.now()}`;
        
        const intervalId = setInterval(async () => {
            try {
                const result = await this.check(command, containerId);
                callback(null, result, checkId);
            } catch (error) {
                callback(error, false, checkId);
            }
        }, interval);

        this.checks.set(checkId, {
            intervalId,
            command,
            containerId,
            startTime: Date.now()
        });

        return checkId;
    }

    stopPeriodicCheck(checkId) {
        const check = this.checks.get(checkId);
        if (check) {
            clearInterval(check.intervalId);
            this.checks.delete(checkId);
            return true;
        }
        return false;
    }

    stopAllChecks() {
        for (const [checkId, check] of this.checks) {
            clearInterval(check.intervalId);
        }
        this.checks.clear();
    }

    // Utility methods
    async isCommandAvailable(command) {
        try {
            await this.execAsync(`which ${command}`);
            return true;
        } catch (error) {
            return false;
        }
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Health check builders for common scenarios
    buildWebAppCheck(port = 3000, path = '/health') {
        return this.httpCheck(`http://localhost:${port}${path}`);
    }

    buildDatabaseCheck(type, options = {}) {
        switch (type.toLowerCase()) {
            case 'mysql':
                return this.mysqlCheck(options);
            case 'postgres':
            case 'postgresql':
                return this.postgresCheck(options);
            case 'redis':
                return this.redisCheck(options);
            default:
                throw new Error(`Unsupported database type: ${type}`);
        }
    }

    buildContainerCheck(containerId, command = 'echo "healthy"') {
        return {
            command: command,
            containerId: containerId,
            options: { timeout: 10000 }
        };
    }

    // Create health check from workflow configuration
    createFromWorkflow(workflow) {
        if (!workflow.healthcheck || !workflow.healthcheck.enabled) {
            return null;
        }

        const { command, interval, timeout, retries } = workflow.healthcheck;
        
        return {
            command: command,
            interval: (interval || 30) * 1000, // Convert to milliseconds
            options: {
                timeout: (timeout || 10) * 1000,
                retries: retries || 3
            }
        };
    }
}

module.exports = HealthCheck;
