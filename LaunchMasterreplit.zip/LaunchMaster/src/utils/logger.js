const fs = require('fs').promises;
const path = require('path');
const os = require('os');

class Logger {
    constructor() {
        this.logDir = path.join(os.homedir(), '.app-launcher', 'logs');
        this.ensureLogDirectory();
    }

    async ensureLogDirectory() {
        try {
            await fs.mkdir(this.logDir, { recursive: true });
        } catch (error) {
            console.error('Failed to create log directory:', error);
        }
    }

    async log(executionId, logEntry) {
        try {
            const logFile = path.join(this.logDir, `${executionId}.log`);
            const logLine = `${logEntry.timestamp} [${logEntry.level.toUpperCase()}] ${logEntry.message}\n`;
            
            await fs.appendFile(logFile, logLine, 'utf8');
        } catch (error) {
            console.error('Failed to write log:', error);
        }
    }

    async getExecutionLogs(executionId) {
        try {
            const logFile = path.join(this.logDir, `${executionId}.log`);
            const content = await fs.readFile(logFile, 'utf8');
            
            return content.split('\n')
                .filter(line => line.trim())
                .map(line => this.parseLogLine(line));
        } catch (error) {
            return [];
        }
    }

    parseLogLine(line) {
        const match = line.match(/^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z) \[(\w+)\] (.+)$/);
        
        if (match) {
            return {
                timestamp: match[1],
                level: match[2].toLowerCase(),
                message: match[3]
            };
        }
        
        return {
            timestamp: new Date().toISOString(),
            level: 'info',
            message: line
        };
    }

    async clearExecutionLogs(executionId) {
        try {
            const logFile = path.join(this.logDir, `${executionId}.log`);
            await fs.unlink(logFile);
        } catch (error) {
            // Ignore if file doesn't exist
        }
    }

    async getLogSummary() {
        try {
            const files = await fs.readdir(this.logDir);
            const logFiles = files.filter(file => file.endsWith('.log'));
            
            const summary = [];
            
            for (const file of logFiles) {
                const filePath = path.join(this.logDir, file);
                const stats = await fs.stat(filePath);
                const executionId = path.basename(file, '.log');
                
                summary.push({
                    executionId,
                    file,
                    size: stats.size,
                    modified: stats.mtime,
                    created: stats.birthtime
                });
            }
            
            return summary.sort((a, b) => b.modified - a.modified);
        } catch (error) {
            return [];
        }
    }

    async cleanupOldLogs(maxAge = 7 * 24 * 60 * 60 * 1000) { // 7 days
        try {
            const files = await fs.readdir(this.logDir);
            const now = Date.now();
            let cleaned = 0;
            
            for (const file of files) {
                if (!file.endsWith('.log')) continue;
                
                const filePath = path.join(this.logDir, file);
                const stats = await fs.stat(filePath);
                
                if (now - stats.mtime.getTime() > maxAge) {
                    await fs.unlink(filePath);
                    cleaned++;
                }
            }
            
            return cleaned;
        } catch (error) {
            console.error('Failed to cleanup old logs:', error);
            return 0;
        }
    }

    async exportLogs(executionId, format = 'text') {
        try {
            const logs = await this.getExecutionLogs(executionId);
            
            if (format === 'json') {
                return JSON.stringify(logs, null, 2);
            } else {
                return logs.map(log => 
                    `${log.timestamp} [${log.level.toUpperCase()}] ${log.message}`
                ).join('\n');
            }
        } catch (error) {
            throw new Error(`Failed to export logs: ${error.message}`);
        }
    }

    // System-level logging methods
    info(message, context = {}) {
        this.systemLog('info', message, context);
    }

    warn(message, context = {}) {
        this.systemLog('warn', message, context);
    }

    error(message, context = {}) {
        this.systemLog('error', message, context);
    }

    debug(message, context = {}) {
        this.systemLog('debug', message, context);
    }

    async systemLog(level, message, context = {}) {
        const logEntry = {
            timestamp: new Date().toISOString(),
            level: level,
            message: message,
            context: context
        };

        try {
            const systemLogFile = path.join(this.logDir, 'system.log');
            const logLine = `${logEntry.timestamp} [${level.toUpperCase()}] ${message}${
                Object.keys(context).length > 0 ? ` ${JSON.stringify(context)}` : ''
            }\n`;
            
            await fs.appendFile(systemLogFile, logLine, 'utf8');
        } catch (error) {
            console.error('Failed to write system log:', error);
        }

        // Also log to console in development
        if (process.env.NODE_ENV === 'development') {
            console.log(`[${level.toUpperCase()}] ${message}`, context);
        }
    }
}

module.exports = Logger;
