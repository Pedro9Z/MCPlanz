const os = require('os');
const { execSync, exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');

class SystemDetection {
    constructor() {
        this.cache = null;
        this.cacheTime = null;
        this.cacheTimeout = 60000; // 1 minute
    }

    async detectSystem() {
        // Return cached result if available and recent
        if (this.cache && this.cacheTime && (Date.now() - this.cacheTime) < this.cacheTimeout) {
            return this.cache;
        }

        const systemInfo = {
            platform: os.platform(),
            arch: os.arch(),
            os: this.getOSName(),
            nodeVersion: process.version,
            homedir: os.homedir(),
            shell: this.getShell(),
            containerEngines: await this.detectContainerEngines(),
            paths: this.getSystemPaths()
        };

        this.cache = systemInfo;
        this.cacheTime = Date.now();
        
        return systemInfo;
    }

    getOSName() {
        const platform = os.platform();
        const release = os.release();
        
        switch (platform) {
            case 'win32':
                return `Windows ${release}`;
            case 'darwin':
                return `macOS ${release}`;
            case 'linux':
                try {
                    const osRelease = execSync('cat /etc/os-release', { encoding: 'utf8' });
                    const prettyName = osRelease.match(/PRETTY_NAME="([^"]+)"/);
                    return prettyName ? prettyName[1] : `Linux ${release}`;
                } catch (error) {
                    return `Linux ${release}`;
                }
            default:
                return `${platform} ${release}`;
        }
    }

    getShell() {
        try {
            if (os.platform() === 'win32') {
                return process.env.COMSPEC || 'cmd.exe';
            } else {
                return process.env.SHELL || '/bin/sh';
            }
        } catch (error) {
            return null;
        }
    }

    getSystemPaths() {
        const paths = (process.env.PATH || '').split(path.delimiter);
        return {
            PATH: process.env.PATH,
            paths: paths.filter(p => p.trim() !== ''),
            commonBinPaths: this.getCommonBinPaths()
        };
    }

    getCommonBinPaths() {
        const platform = os.platform();
        if (platform === 'win32') {
            return [
                'C:\\Windows\\System32',
                'C:\\Windows',
                'C:\\Program Files',
                'C:\\Program Files (x86)'
            ];
        } else {
            return [
                '/usr/local/bin',
                '/usr/bin',
                '/bin',
                '/usr/sbin',
                '/sbin'
            ];
        }
    }

    async detectContainerEngines() {
        const engines = [
            { name: 'Docker', command: 'docker --version' },
            { name: 'Podman', command: 'podman --version' }
        ];

        const results = await Promise.all(
            engines.map(engine => this.checkContainerEngine(engine))
        );

        return results;
    }

    async checkContainerEngine(engine) {
        return new Promise((resolve) => {
            exec(engine.command, { timeout: 5000 }, (error, stdout, stderr) => {
                if (error) {
                    resolve({
                        name: engine.name,
                        available: false,
                        error: error.message,
                        command: engine.command
                    });
                } else {
                    const version = this.parseVersion(stdout);
                    resolve({
                        name: engine.name,
                        available: true,
                        version: version,
                        command: engine.command,
                        output: stdout.trim()
                    });
                }
            });
        });
    }

    parseVersion(output) {
        // Extract version from common version output formats
        const versionMatch = output.match(/version\s+(\d+\.\d+\.\d+[^\s]*)/i) ||
                           output.match(/(\d+\.\d+\.\d+[^\s]*)/);
        return versionMatch ? versionMatch[1] : 'Unknown';
    }

    async checkDependency(command) {
        try {
            execSync(`${command} --version`, { 
                encoding: 'utf8', 
                timeout: 5000,
                stdio: 'pipe'
            });
            return true;
        } catch (error) {
            return false;
        }
    }

    async validateWorkflowDependencies(workflow) {
        const missing = [];
        
        if (workflow.mode === 'container') {
            const containerEngines = await this.detectContainerEngines();
            const hasAvailableEngine = containerEngines.some(engine => engine.available);
            
            if (!hasAvailableEngine) {
                missing.push('Container engine (Docker or Podman)');
            }
        }

        // Check for specific commands in steps
        if (workflow.steps) {
            for (const step of workflow.steps) {
                const commands = this.extractCommands(step.command);
                for (const cmd of commands) {
                    const available = await this.checkDependency(cmd);
                    if (!available && !missing.includes(cmd)) {
                        missing.push(cmd);
                    }
                }
            }
        }

        return {
            valid: missing.length === 0,
            missing: missing
        };
    }

    extractCommands(commandString) {
        // Extract base commands from complex command strings
        const commands = [];
        const parts = commandString.split(/[;&|]+/);
        
        for (const part of parts) {
            const trimmed = part.trim();
            if (trimmed) {
                const firstWord = trimmed.split(/\s+/)[0];
                if (firstWord && !firstWord.startsWith('-')) {
                    commands.push(firstWord);
                }
            }
        }
        
        return commands;
    }

    async getSystemResources() {
        return {
            totalMemory: os.totalmem(),
            freeMemory: os.freemem(),
            cpus: os.cpus().length,
            loadAverage: os.loadavg(),
            uptime: os.uptime()
        };
    }
}

module.exports = SystemDetection;
