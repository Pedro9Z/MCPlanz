const { spawn, exec } = require('child_process');
const EventEmitter = require('events');
const ContainerManager = require('./containerManager');
const Logger = require('../utils/logger');
const HealthCheck = require('../utils/healthCheck');

class WorkflowEngine extends EventEmitter {
    constructor() {
        super();
        this.executions = new Map();
        this.containerManager = new ContainerManager();
        this.logger = new Logger();
        this.healthCheck = new HealthCheck();
    }

    execute(workflow) {
        const executionId = this.generateExecutionId();
        const execution = {
            id: executionId,
            workflow: workflow,
            status: 'starting',
            startTime: new Date(),
            currentStep: 0,
            totalSteps: workflow.steps?.length || 0,
            logs: [],
            processes: [],
            containers: [],
            healthCheckInterval: null
        };

        this.executions.set(executionId, execution);
        
        // Start execution asynchronously
        this.runWorkflow(execution).catch(error => {
            this.handleExecutionError(execution, error);
        });

        return executionId;
    }

    async runWorkflow(execution) {
        try {
            execution.status = 'running';
            this.emitUpdate(execution);

            if (execution.workflow.mode === 'container') {
                await this.runContainerWorkflow(execution);
            } else {
                await this.runNativeWorkflow(execution);
            }

            // Start health checks if configured
            if (execution.workflow.healthcheck?.enabled) {
                this.startHealthCheck(execution);
            }

            execution.status = 'completed';
            execution.endTime = new Date();
            this.emitUpdate(execution);

        } catch (error) {
            this.handleExecutionError(execution, error);
        }
    }

    async runNativeWorkflow(execution) {
        const { workflow } = execution;
        
        for (let i = 0; i < workflow.steps.length; i++) {
            const step = workflow.steps[i];
            execution.currentStep = i + 1;
            
            this.addLog(execution, `Starting step ${i + 1}: ${step.name}`, 'info');
            this.emitUpdate(execution);

            try {
                await this.executeNativeStep(execution, step);
                this.addLog(execution, `Completed step ${i + 1}: ${step.name}`, 'info');
            } catch (error) {
                this.addLog(execution, `Failed step ${i + 1}: ${error.message}`, 'error');
                throw error;
            }
        }
    }

    async runContainerWorkflow(execution) {
        const { workflow } = execution;
        
        try {
            // Create and start container
            const containerId = await this.containerManager.createContainer({
                image: workflow.image,
                ports: workflow.ports,
                volumes: workflow.volumes,
                environment: workflow.environment,
                name: `workflow-${execution.id}`
            });

            execution.containers.push(containerId);
            this.addLog(execution, `Created container: ${containerId}`, 'info');

            await this.containerManager.startContainer(containerId);
            this.addLog(execution, `Started container: ${containerId}`, 'info');

            // Execute steps inside container
            for (let i = 0; i < workflow.steps.length; i++) {
                const step = workflow.steps[i];
                execution.currentStep = i + 1;
                
                this.addLog(execution, `Starting step ${i + 1}: ${step.name}`, 'info');
                this.emitUpdate(execution);

                try {
                    await this.executeContainerStep(execution, containerId, step);
                    this.addLog(execution, `Completed step ${i + 1}: ${step.name}`, 'info');
                } catch (error) {
                    this.addLog(execution, `Failed step ${i + 1}: ${error.message}`, 'error');
                    throw error;
                }
            }

        } catch (error) {
            this.addLog(execution, `Container workflow failed: ${error.message}`, 'error');
            throw error;
        }
    }

    async executeNativeStep(execution, step) {
        return new Promise((resolve, reject) => {
            const workdir = step.workdir || process.cwd();
            const timeout = step.timeout > 0 ? step.timeout * 1000 : 0;

            const child = spawn(step.command, [], {
                shell: true,
                cwd: workdir,
                stdio: ['ignore', 'pipe', 'pipe']
            });

            execution.processes.push(child);

            let timeoutId;
            if (timeout > 0) {
                timeoutId = setTimeout(() => {
                    child.kill('SIGTERM');
                    reject(new Error(`Step timed out after ${step.timeout} seconds`));
                }, timeout);
            }

            child.stdout.on('data', (data) => {
                const message = data.toString().trim();
                if (message) {
                    this.addLog(execution, message, 'stdout');
                }
            });

            child.stderr.on('data', (data) => {
                const message = data.toString().trim();
                if (message) {
                    this.addLog(execution, message, 'stderr');
                }
            });

            child.on('close', (code) => {
                if (timeoutId) {
                    clearTimeout(timeoutId);
                }

                if (code === 0) {
                    resolve();
                } else {
                    reject(new Error(`Step exited with code ${code}`));
                }
            });

            child.on('error', (error) => {
                if (timeoutId) {
                    clearTimeout(timeoutId);
                }
                reject(error);
            });
        });
    }

    async executeContainerStep(execution, containerId, step) {
        const command = step.command;
        const workdir = step.workdir || '/app';
        
        return this.containerManager.execCommand(containerId, command, {
            workdir: workdir,
            timeout: step.timeout
        });
    }

    startHealthCheck(execution) {
        const { healthcheck } = execution.workflow;
        
        execution.healthCheckInterval = setInterval(async () => {
            try {
                const isHealthy = await this.healthCheck.check(
                    healthcheck.command,
                    execution.workflow.mode === 'container' ? execution.containers[0] : null
                );

                this.addLog(execution, `Health check: ${isHealthy ? 'PASS' : 'FAIL'}`, 'info');
                
                if (!isHealthy) {
                    this.addLog(execution, 'Health check failed - workflow may be unhealthy', 'warning');
                }

            } catch (error) {
                this.addLog(execution, `Health check error: ${error.message}`, 'error');
            }
        }, healthcheck.interval * 1000);
    }

    async stop(executionId) {
        const execution = this.executions.get(executionId);
        if (!execution) {
            throw new Error('Execution not found');
        }

        execution.status = 'stopping';
        this.emitUpdate(execution);

        try {
            // Stop health checks
            if (execution.healthCheckInterval) {
                clearInterval(execution.healthCheckInterval);
            }

            // Kill running processes
            for (const process of execution.processes) {
                if (!process.killed) {
                    process.kill('SIGTERM');
                    
                    // Force kill after 5 seconds
                    setTimeout(() => {
                        if (!process.killed) {
                            process.kill('SIGKILL');
                        }
                    }, 5000);
                }
            }

            // Stop containers
            for (const containerId of execution.containers) {
                await this.containerManager.stopContainer(containerId);
                await this.containerManager.removeContainer(containerId);
            }

            execution.status = 'stopped';
            execution.endTime = new Date();
            this.addLog(execution, 'Execution stopped by user', 'info');
            this.emitUpdate(execution);

        } catch (error) {
            this.addLog(execution, `Error stopping execution: ${error.message}`, 'error');
            execution.status = 'failed';
            this.emitUpdate(execution);
        }
    }

    getStatus(executionId) {
        const execution = this.executions.get(executionId);
        if (!execution) {
            throw new Error('Execution not found');
        }

        return {
            id: execution.id,
            status: execution.status,
            workflow: execution.workflow.name,
            currentStep: execution.currentStep,
            totalSteps: execution.totalSteps,
            startTime: execution.startTime,
            endTime: execution.endTime,
            logs: execution.logs.slice(-100) // Return last 100 log entries
        };
    }

    handleExecutionError(execution, error) {
        execution.status = 'failed';
        execution.endTime = new Date();
        this.addLog(execution, `Execution failed: ${error.message}`, 'error');
        this.emitUpdate(execution);

        // Cleanup on error
        this.cleanup(execution).catch(cleanupError => {
            this.addLog(execution, `Cleanup error: ${cleanupError.message}`, 'error');
        });
    }

    async cleanup(execution) {
        // Stop health checks
        if (execution.healthCheckInterval) {
            clearInterval(execution.healthCheckInterval);
        }

        // Kill processes
        for (const process of execution.processes) {
            if (!process.killed) {
                process.kill('SIGKILL');
            }
        }

        // Remove containers
        for (const containerId of execution.containers) {
            try {
                await this.containerManager.stopContainer(containerId);
                await this.containerManager.removeContainer(containerId);
            } catch (error) {
                // Ignore cleanup errors for containers
            }
        }
    }

    addLog(execution, message, level = 'info') {
        const logEntry = {
            timestamp: new Date().toISOString(),
            level: level,
            message: message,
            type: level === 'stderr' ? 'stderr' : 'stdout'
        };

        execution.logs.push(logEntry);
        
        // Keep only last 1000 log entries to prevent memory issues
        if (execution.logs.length > 1000) {
            execution.logs = execution.logs.slice(-1000);
        }

        this.logger.log(execution.id, logEntry);
    }

    emitUpdate(execution) {
        this.emit('execution-update', {
            id: execution.id,
            status: execution.status,
            currentStep: execution.currentStep,
            totalSteps: execution.totalSteps
        });
    }

    generateExecutionId() {
        return `exec_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    // Cleanup old executions periodically
    cleanupOldExecutions() {
        const now = Date.now();
        const maxAge = 24 * 60 * 60 * 1000; // 24 hours

        for (const [id, execution] of this.executions) {
            if (execution.endTime && (now - new Date(execution.endTime).getTime()) > maxAge) {
                this.executions.delete(id);
            }
        }
    }
}

module.exports = WorkflowEngine;
