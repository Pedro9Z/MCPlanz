const { exec, spawn } = require('child_process');
const { promisify } = require('util');

class ContainerManager {
    constructor() {
        this.execAsync = promisify(exec);
        this.defaultEngine = null;
        this.availableEngines = [];
    }

    async initialize() {
        // Detect available container engines
        const engines = ['docker', 'podman'];
        
        for (const engine of engines) {
            try {
                await this.execAsync(`${engine} --version`);
                this.availableEngines.push(engine);
                if (!this.defaultEngine) {
                    this.defaultEngine = engine;
                }
            } catch (error) {
                // Engine not available
            }
        }

        if (!this.defaultEngine) {
            throw new Error('No container engine available (Docker or Podman required)');
        }
    }

    async createContainer(options) {
        if (!this.defaultEngine) {
            await this.initialize();
        }

        const {
            image,
            name,
            ports = [],
            volumes = [],
            environment = {},
            workdir = '/app',
            detach = true
        } = options;

        const args = [this.defaultEngine, 'create'];

        // Add name
        if (name) {
            args.push('--name', name);
        }

        // Add ports
        for (const port of ports) {
            args.push('-p', port);
        }

        // Add volumes
        for (const volume of volumes) {
            args.push('-v', volume);
        }

        // Add environment variables
        for (const [key, value] of Object.entries(environment)) {
            args.push('-e', `${key}=${value}`);
        }

        // Add working directory
        if (workdir) {
            args.push('-w', workdir);
        }

        // Add detach flag
        if (detach) {
            args.push('-d');
        }

        // Add image
        args.push(image);

        try {
            const { stdout } = await this.execAsync(args.join(' '));
            return stdout.trim();
        } catch (error) {
            throw new Error(`Failed to create container: ${error.message}`);
        }
    }

    async startContainer(containerId) {
        if (!this.defaultEngine) {
            await this.initialize();
        }

        try {
            await this.execAsync(`${this.defaultEngine} start ${containerId}`);
        } catch (error) {
            throw new Error(`Failed to start container: ${error.message}`);
        }
    }

    async stopContainer(containerId) {
        if (!this.defaultEngine) {
            await this.initialize();
        }

        try {
            await this.execAsync(`${this.defaultEngine} stop ${containerId}`);
        } catch (error) {
            throw new Error(`Failed to stop container: ${error.message}`);
        }
    }

    async removeContainer(containerId) {
        if (!this.defaultEngine) {
            await this.initialize();
        }

        try {
            await this.execAsync(`${this.defaultEngine} rm ${containerId}`);
        } catch (error) {
            throw new Error(`Failed to remove container: ${error.message}`);
        }
    }

    async execCommand(containerId, command, options = {}) {
        if (!this.defaultEngine) {
            await this.initialize();
        }

        const { workdir, timeout = 0 } = options;

        return new Promise((resolve, reject) => {
            const args = [this.defaultEngine, 'exec'];

            if (workdir) {
                args.push('-w', workdir);
            }

            args.push(containerId, 'sh', '-c', command);

            const child = spawn(args[0], args.slice(1), {
                stdio: ['ignore', 'pipe', 'pipe']
            });

            let stdout = '';
            let stderr = '';
            let timeoutId;

            if (timeout > 0) {
                timeoutId = setTimeout(() => {
                    child.kill('SIGTERM');
                    reject(new Error(`Command timed out after ${timeout} seconds`));
                }, timeout * 1000);
            }

            child.stdout.on('data', (data) => {
                stdout += data.toString();
            });

            child.stderr.on('data', (data) => {
                stderr += data.toString();
            });

            child.on('close', (code) => {
                if (timeoutId) {
                    clearTimeout(timeoutId);
                }

                if (code === 0) {
                    resolve({ stdout, stderr, code });
                } else {
                    reject(new Error(`Command exited with code ${code}: ${stderr}`));
                }
            });

            child.on('error', (error) => {
                if (timeoutId) {
                    clearTimeout(timeoutId);
                }
                reject(error);
            });
        });
    }

    async getContainerStatus(containerId) {
        if (!this.defaultEngine) {
            await this.initialize();
        }

        try {
            const { stdout } = await this.execAsync(
                `${this.defaultEngine} inspect ${containerId} --format='{{.State.Status}}'`
            );
            return stdout.trim();
        } catch (error) {
            throw new Error(`Failed to get container status: ${error.message}`);
        }
    }

    async getContainerLogs(containerId, options = {}) {
        if (!this.defaultEngine) {
            await this.initialize();
        }

        const { tail = 100, follow = false } = options;
        const args = [this.defaultEngine, 'logs'];

        if (tail) {
            args.push('--tail', tail.toString());
        }

        if (follow) {
            args.push('-f');
        }

        args.push(containerId);

        try {
            const { stdout, stderr } = await this.execAsync(args.join(' '));
            return { stdout, stderr };
        } catch (error) {
            throw new Error(`Failed to get container logs: ${error.message}`);
        }
    }

    async pullImage(image) {
        if (!this.defaultEngine) {
            await this.initialize();
        }

        try {
            await this.execAsync(`${this.defaultEngine} pull ${image}`);
        } catch (error) {
            throw new Error(`Failed to pull image: ${error.message}`);
        }
    }

    async listImages() {
        if (!this.defaultEngine) {
            await this.initialize();
        }

        try {
            const { stdout } = await this.execAsync(
                `${this.defaultEngine} images --format="table {{.Repository}}:{{.Tag}}\t{{.ID}}\t{{.Size}}"`
            );
            return this.parseImageList(stdout);
        } catch (error) {
            throw new Error(`Failed to list images: ${error.message}`);
        }
    }

    parseImageList(output) {
        const lines = output.trim().split('\n');
        const images = [];

        for (let i = 1; i < lines.length; i++) { // Skip header
            const parts = lines[i].split('\t');
            if (parts.length >= 3) {
                images.push({
                    name: parts[0],
                    id: parts[1],
                    size: parts[2]
                });
            }
        }

        return images;
    }

    async cleanupContainers(filter = {}) {
        if (!this.defaultEngine) {
            await this.initialize();
        }

        try {
            // Stop and remove containers based on filter
            const { name, status, age } = filter;
            let command = `${this.defaultEngine} ps -aq`;

            if (name) {
                command += ` --filter name=${name}`;
            }

            if (status) {
                command += ` --filter status=${status}`;
            }

            const { stdout } = await this.execAsync(command);
            const containerIds = stdout.trim().split('\n').filter(id => id);

            for (const containerId of containerIds) {
                try {
                    await this.stopContainer(containerId);
                    await this.removeContainer(containerId);
                } catch (error) {
                    // Ignore individual cleanup errors
                }
            }

            return containerIds.length;
        } catch (error) {
            throw new Error(`Failed to cleanup containers: ${error.message}`);
        }
    }

    getEngine() {
        return this.defaultEngine;
    }

    isAvailable() {
        return this.availableEngines.length > 0;
    }
}

module.exports = ContainerManager;
