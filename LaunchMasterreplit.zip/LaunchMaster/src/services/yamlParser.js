const yaml = require('js-yaml');

class YamlParser {
    constructor() {
        this.schema = this.createValidationSchema();
    }

    parse(yamlContent) {
        try {
            const parsed = yaml.load(yamlContent);
            return this.validateAndNormalize(parsed);
        } catch (error) {
            throw new Error(`YAML parsing error: ${error.message}`);
        }
    }

    stringify(workflow) {
        try {
            return yaml.dump(workflow, {
                indent: 2,
                lineWidth: 100,
                noRefs: true,
                sortKeys: false
            });
        } catch (error) {
            throw new Error(`YAML serialization error: ${error.message}`);
        }
    }

    validateAndNormalize(workflow) {
        const errors = [];

        // Required fields
        if (!workflow.name || typeof workflow.name !== 'string') {
            errors.push('Workflow must have a valid name');
        }

        if (!workflow.mode || !['native', 'container'].includes(workflow.mode)) {
            errors.push('Workflow mode must be either "native" or "container"');
        }

        if (!workflow.steps || !Array.isArray(workflow.steps) || workflow.steps.length === 0) {
            errors.push('Workflow must have at least one step');
        }

        // Validate steps
        if (workflow.steps) {
            workflow.steps.forEach((step, index) => {
                if (!step.name || typeof step.name !== 'string') {
                    errors.push(`Step ${index + 1} must have a valid name`);
                }

                if (!step.command || typeof step.command !== 'string') {
                    errors.push(`Step ${index + 1} must have a valid command`);
                }

                // Normalize step properties
                step.workdir = step.workdir || '.';
                step.timeout = typeof step.timeout === 'number' ? step.timeout : 30;
            });
        }

        // Container mode specific validation
        if (workflow.mode === 'container') {
            if (!workflow.image || typeof workflow.image !== 'string') {
                errors.push('Container workflows must specify a Docker image');
            }

            // Normalize container properties
            workflow.ports = this.normalizePorts(workflow.ports);
            workflow.volumes = this.normalizeVolumes(workflow.volumes);
            workflow.environment = this.normalizeEnvironment(workflow.environment);
        }

        // Validate health check
        if (workflow.healthcheck) {
            if (workflow.healthcheck.enabled && !workflow.healthcheck.command) {
                errors.push('Health check must specify a command when enabled');
            }

            // Normalize health check
            workflow.healthcheck.interval = workflow.healthcheck.interval || 30;
            workflow.healthcheck.timeout = workflow.healthcheck.timeout || 10;
            workflow.healthcheck.retries = workflow.healthcheck.retries || 3;
        }

        if (errors.length > 0) {
            throw new Error(`Validation errors:\n${errors.join('\n')}`);
        }

        return this.applyDefaults(workflow);
    }

    applyDefaults(workflow) {
        // Apply default values
        const normalized = {
            name: workflow.name,
            description: workflow.description || '',
            mode: workflow.mode,
            steps: workflow.steps.map(step => ({
                name: step.name,
                command: step.command,
                workdir: step.workdir || '.',
                timeout: typeof step.timeout === 'number' ? step.timeout : 30
            })),
            ...workflow
        };

        if (workflow.mode === 'container') {
            normalized.image = workflow.image;
            normalized.ports = workflow.ports || [];
            normalized.volumes = workflow.volumes || [];
            normalized.environment = workflow.environment || {};
        }

        if (workflow.healthcheck) {
            normalized.healthcheck = {
                enabled: workflow.healthcheck.enabled || false,
                command: workflow.healthcheck.command || '',
                interval: workflow.healthcheck.interval || 30,
                timeout: workflow.healthcheck.timeout || 10,
                retries: workflow.healthcheck.retries || 3
            };
        }

        return normalized;
    }

    normalizePorts(ports) {
        if (!ports) return [];
        
        if (typeof ports === 'string') {
            return ports.split(',').map(p => p.trim()).filter(p => p);
        }
        
        if (Array.isArray(ports)) {
            return ports.map(p => typeof p === 'string' ? p.trim() : String(p)).filter(p => p);
        }
        
        return [];
    }

    normalizeVolumes(volumes) {
        if (!volumes) return [];
        
        if (typeof volumes === 'string') {
            return volumes.split(',').map(v => v.trim()).filter(v => v);
        }
        
        if (Array.isArray(volumes)) {
            return volumes.map(v => typeof v === 'string' ? v.trim() : String(v)).filter(v => v);
        }
        
        return [];
    }

    normalizeEnvironment(environment) {
        if (!environment) return {};
        
        if (typeof environment === 'object' && !Array.isArray(environment)) {
            return environment;
        }
        
        if (typeof environment === 'string') {
            const env = {};
            environment.split('\n').forEach(line => {
                const trimmed = line.trim();
                if (trimmed && trimmed.includes('=')) {
                    const [key, ...values] = trimmed.split('=');
                    env[key.trim()] = values.join('=').trim();
                }
            });
            return env;
        }
        
        if (Array.isArray(environment)) {
            const env = {};
            environment.forEach(item => {
                if (typeof item === 'string' && item.includes('=')) {
                    const [key, ...values] = item.split('=');
                    env[key.trim()] = values.join('=').trim();
                }
            });
            return env;
        }
        
        return {};
    }

    createValidationSchema() {
        // Define JSON schema for workflow validation
        return {
            type: 'object',
            required: ['name', 'mode', 'steps'],
            properties: {
                name: { type: 'string', minLength: 1 },
                description: { type: 'string' },
                mode: { enum: ['native', 'container'] },
                steps: {
                    type: 'array',
                    minItems: 1,
                    items: {
                        type: 'object',
                        required: ['name', 'command'],
                        properties: {
                            name: { type: 'string', minLength: 1 },
                            command: { type: 'string', minLength: 1 },
                            workdir: { type: 'string' },
                            timeout: { type: 'number', minimum: 0 }
                        }
                    }
                },
                image: { type: 'string' },
                ports: {
                    type: 'array',
                    items: { type: 'string' }
                },
                volumes: {
                    type: 'array',
                    items: { type: 'string' }
                },
                environment: { type: 'object' },
                healthcheck: {
                    type: 'object',
                    properties: {
                        enabled: { type: 'boolean' },
                        command: { type: 'string' },
                        interval: { type: 'number', minimum: 1 },
                        timeout: { type: 'number', minimum: 1 },
                        retries: { type: 'number', minimum: 1 }
                    }
                }
            }
        };
    }

    // Create workflow from template
    createFromTemplate(templateName, options = {}) {
        const templates = {
            'webdev-native': {
                name: 'Web Development (Native)',
                description: 'Local web development environment setup',
                mode: 'native',
                steps: [
                    {
                        name: 'Install Dependencies',
                        command: 'npm install',
                        workdir: '.',
                        timeout: 120
                    },
                    {
                        name: 'Start Development Server',
                        command: 'npm run dev',
                        workdir: '.',
                        timeout: 0
                    }
                ],
                healthcheck: {
                    enabled: true,
                    command: 'curl -f http://localhost:3000/health || curl -f http://localhost:3000',
                    interval: 30
                }
            },
            'webdev-container': {
                name: 'Web Development (Container)',
                description: 'Containerized web development environment',
                mode: 'container',
                image: 'node:16-alpine',
                ports: ['3000:3000'],
                volumes: ['./src:/app/src', './package.json:/app/package.json'],
                environment: {
                    NODE_ENV: 'development',
                    PORT: '3000'
                },
                steps: [
                    {
                        name: 'Install Dependencies',
                        command: 'npm install',
                        workdir: '/app',
                        timeout: 120
                    },
                    {
                        name: 'Start Development Server',
                        command: 'npm run dev',
                        workdir: '/app',
                        timeout: 0
                    }
                ],
                healthcheck: {
                    enabled: true,
                    command: 'curl -f http://localhost:3000/health || curl -f http://localhost:3000',
                    interval: 30
                }
            },
            'creative-suite': {
                name: 'Creative Suite',
                description: 'Launch creative applications and tools',
                mode: 'native',
                steps: [
                    {
                        name: 'Open Image Editor',
                        command: 'gimp',
                        workdir: '.',
                        timeout: 10
                    },
                    {
                        name: 'Open Vector Editor',
                        command: 'inkscape',
                        workdir: '.',
                        timeout: 10
                    }
                ]
            }
        };

        const template = templates[templateName];
        if (!template) {
            throw new Error(`Template '${templateName}' not found`);
        }

        // Apply options to override template values
        return { ...template, ...options };
    }
}

module.exports = YamlParser;
