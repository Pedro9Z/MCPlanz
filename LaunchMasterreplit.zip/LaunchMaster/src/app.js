const React = window.React;
const ReactDOM = window.ReactDOM;
const App = window.App;

// Web API wrapper to replace Electron API
window.electronAPI = {
    // System operations
    getSystemInfo: () => fetch('/api/system-info').then(r => r.json()),
    
    // Workflow management
    loadWorkflows: () => fetch('/api/workflows').then(r => r.json()),
    saveWorkflow: (workflow) => fetch('/api/workflows', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(workflow)
    }).then(r => r.json()),
    deleteWorkflow: (filename) => fetch(`/api/workflows/${filename}`, {
        method: 'DELETE'
    }).then(r => r.json()),
    
    // Workflow execution
    executeWorkflow: (workflow) => fetch('/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(workflow)
    }).then(r => r.json()),
    stopWorkflow: (executionId) => fetch(`/api/stop/${executionId}`, {
        method: 'POST'
    }).then(r => r.json()),
    getExecutionStatus: (executionId) => fetch(`/api/status/${executionId}`).then(r => r.json()),
    
    // File operations
    importWorkflow: async () => {
        return new Promise((resolve) => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.yaml,.yml';
            input.onchange = async (e) => {
                const file = e.target.files[0];
                if (file) {
                    const content = await file.text();
                    const result = await fetch('/api/import', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ content })
                    }).then(r => r.json());
                    resolve(result);
                } else {
                    resolve({ success: false, error: 'Import cancelled' });
                }
            };
            input.click();
        });
    },
    exportWorkflow: async (workflow) => {
        const result = await fetch('/api/export', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(workflow)
        }).then(r => r.json());
        
        if (result.success) {
            const blob = new Blob([result.data], { type: 'text/yaml' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${workflow.name.replace(/\s+/g, '-').toLowerCase()}.yaml`;
            a.click();
            URL.revokeObjectURL(url);
            return { success: true };
        }
        return result;
    },
    
    // Event listeners (WebSocket implementation)
    onWorkflowUpdate: (callback) => {
        if (window.socket) {
            window.socket.on('workflow-update', callback);
        }
    },
    onExecutionUpdate: (callback) => {
        if (window.socket) {
            window.socket.on('execution-update', callback);
        }
    },
    onSystemUpdate: (callback) => {
        if (window.socket) {
            window.socket.on('system-update', callback);
        }
    }
};

// Initialize Socket.IO for real-time updates
if (typeof io !== 'undefined') {
    window.socket = io();
    console.log('Socket.IO initialized');
}

// Initialize React app
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
