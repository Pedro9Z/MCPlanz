const { useState } = React;

const SystemStatus = ({ systemInfo }) => {
    const [showDetails, setShowDetails] = useState(false);

    if (!systemInfo) {
        return (
            <div className="system-status loading">
                <span>Detecting system...</span>
            </div>
        );
    }

    const getContainerStatus = () => {
        if (systemInfo.containerEngines && systemInfo.containerEngines.length > 0) {
            const available = systemInfo.containerEngines.filter(engine => engine.available);
            if (available.length > 0) {
                return { status: 'available', engines: available };
            }
        }
        return { status: 'unavailable', engines: [] };
    };

    const containerStatus = getContainerStatus();

    return (
        <div className="system-status">
            <div className="status-summary" onClick={() => setShowDetails(!showDetails)}>
                <div className="os-info">
                    <span className="os-icon">
                        {systemInfo.platform === 'win32' ? '🪟' : 
                         systemInfo.platform === 'darwin' ? '🍎' : '🐧'}
                    </span>
                    <span>{systemInfo.os}</span>
                </div>
                
                <div className="container-info">
                    <span className={`container-status ${containerStatus.status}`}>
                        {containerStatus.status === 'available' ? '🐳' : '❌'}
                    </span>
                    <span>{containerStatus.engines.length > 0 ? containerStatus.engines[0].name : 'No containers'}</span>
                </div>
                
                <button className="details-toggle">
                    {showDetails ? '▲' : '▼'}
                </button>
            </div>

            {showDetails && (
                <div className="status-details">
                    <div className="detail-section">
                        <h4>System Information</h4>
                        <div className="detail-grid">
                            <div className="detail-item">
                                <label>Operating System:</label>
                                <span>{systemInfo.os} {systemInfo.arch}</span>
                            </div>
                            <div className="detail-item">
                                <label>Platform:</label>
                                <span>{systemInfo.platform}</span>
                            </div>
                            <div className="detail-item">
                                <label>Node.js Version:</label>
                                <span>{systemInfo.nodeVersion}</span>
                            </div>
                            <div className="detail-item">
                                <label>Home Directory:</label>
                                <span>{systemInfo.homedir}</span>
                            </div>
                        </div>
                    </div>

                    <div className="detail-section">
                        <h4>Container Engines</h4>
                        {systemInfo.containerEngines && systemInfo.containerEngines.length > 0 ? (
                            <div className="container-engines">
                                {systemInfo.containerEngines.map((engine, index) => (
                                    <div key={index} className={`engine-item ${engine.available ? 'available' : 'unavailable'}`}>
                                        <div className="engine-header">
                                            <span className="engine-name">{engine.name}</span>
                                            <span className={`engine-status ${engine.available ? 'available' : 'unavailable'}`}>
                                                {engine.available ? '✓ Available' : '✗ Unavailable'}
                                            </span>
                                        </div>
                                        {engine.version && (
                                            <div className="engine-version">
                                                Version: {engine.version}
                                            </div>
                                        )}
                                        {engine.error && (
                                            <div className="engine-error">
                                                Error: {engine.error}
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="no-engines">
                                <p>No container engines detected</p>
                                <p className="hint">Install Docker or Podman to enable container workflows</p>
                            </div>
                        )}
                    </div>

                    <div className="detail-section">
                        <h4>Capabilities</h4>
                        <div className="capabilities">
                            <div className={`capability ${true ? 'available' : 'unavailable'}`}>
                                <span>✓ Native workflows</span>
                            </div>
                            <div className={`capability ${containerStatus.status === 'available' ? 'available' : 'unavailable'}`}>
                                <span>{containerStatus.status === 'available' ? '✓' : '✗'} Container workflows</span>
                            </div>
                            <div className={`capability ${systemInfo.shell ? 'available' : 'unavailable'}`}>
                                <span>{systemInfo.shell ? '✓' : '✗'} Shell access</span>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

window.SystemStatus = SystemStatus;
