const { useState, useEffect } = React;

const ExecutionMonitor = ({ executions, onStop }) => {
    const [selectedExecution, setSelectedExecution] = useState(null);
    const [logs, setLogs] = useState({});
    const [autoScroll, setAutoScroll] = useState(true);

    useEffect(() => {
        // Poll for execution updates
        const interval = setInterval(async () => {
            for (const executionId in executions) {
                try {
                    const result = await window.electronAPI.getExecutionStatus(executionId);
                    if (result.success) {
                        // Update logs and status
                        setLogs(prev => ({
                            ...prev,
                            [executionId]: result.data.logs || []
                        }));
                    }
                } catch (error) {
                    console.error('Failed to get execution status:', error);
                }
            }
        }, 1000);

        return () => clearInterval(interval);
    }, [executions]);

    const getStatusIcon = (status) => {
        switch (status) {
            case 'running': return '🔄';
            case 'completed': return '✅';
            case 'failed': return '❌';
            case 'stopped': return '⏹️';
            default: return '❓';
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'running': return 'status-running';
            case 'completed': return 'status-completed';
            case 'failed': return 'status-failed';
            case 'stopped': return 'status-stopped';
            default: return 'status-unknown';
        }
    };

    const formatDuration = (startTime, endTime) => {
        const start = new Date(startTime);
        const end = endTime ? new Date(endTime) : new Date();
        const duration = Math.floor((end - start) / 1000);
        
        const hours = Math.floor(duration / 3600);
        const minutes = Math.floor((duration % 3600) / 60);
        const seconds = duration % 60;
        
        if (hours > 0) {
            return `${hours}h ${minutes}m ${seconds}s`;
        } else if (minutes > 0) {
            return `${minutes}m ${seconds}s`;
        } else {
            return `${seconds}s`;
        }
    };

    const renderLogLine = (line, index) => {
        const isError = line.type === 'stderr' || line.level === 'error';
        const isWarning = line.level === 'warning';
        
        return (
            <div key={index} className={`log-line ${isError ? 'log-error' : ''} ${isWarning ? 'log-warning' : ''}`}>
                <span className="log-timestamp">{new Date(line.timestamp).toLocaleTimeString()}</span>
                <span className="log-content">{line.message}</span>
            </div>
        );
    };

    const executionList = Object.values(executions);

    return (
        <div className="execution-monitor">
            <div className="monitor-header">
                <h2>Execution Monitor</h2>
                <div className="monitor-stats">
                    <span className="stat">
                        Running: {executionList.filter(e => e.status === 'running').length}
                    </span>
                    <span className="stat">
                        Completed: {executionList.filter(e => e.status === 'completed').length}
                    </span>
                    <span className="stat">
                        Failed: {executionList.filter(e => e.status === 'failed').length}
                    </span>
                </div>
            </div>

            <div className="monitor-content">
                <div className="execution-list">
                    {executionList.length === 0 ? (
                        <div className="empty-state">
                            <h3>No active executions</h3>
                            <p>Launch a workflow to see execution status here</p>
                        </div>
                    ) : (
                        executionList.map(execution => (
                            <div
                                key={execution.id}
                                className={`execution-item ${selectedExecution === execution.id ? 'selected' : ''} ${getStatusColor(execution.status)}`}
                                onClick={() => setSelectedExecution(execution.id)}
                            >
                                <div className="execution-header">
                                    <div className="execution-info">
                                        <span className="status-icon">{getStatusIcon(execution.status)}</span>
                                        <div className="execution-details">
                                            <h4>{execution.workflow}</h4>
                                            <span className="execution-id">ID: {execution.id}</span>
                                        </div>
                                    </div>
                                    <div className="execution-meta">
                                        <span className="duration">
                                            {formatDuration(execution.startTime, execution.endTime)}
                                        </span>
                                        {execution.status === 'running' && (
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    onStop(execution.id);
                                                }}
                                                className="btn btn-danger btn-sm"
                                            >
                                                Stop
                                            </button>
                                        )}
                                    </div>
                                </div>
                                
                                <div className="execution-progress">
                                    <div className="progress-info">
                                        <span>Step {execution.currentStep || 0} of {execution.totalSteps || 0}</span>
                                        <span className="status-text">{execution.status}</span>
                                    </div>
                                    {execution.totalSteps > 0 && (
                                        <div className="progress-bar">
                                            <div
                                                className="progress-fill"
                                                style={{
                                                    width: `${((execution.currentStep || 0) / execution.totalSteps) * 100}%`
                                                }}
                                            />
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))
                    )}
                </div>

                {selectedExecution && (
                    <div className="execution-details">
                        <div className="details-header">
                            <h3>Execution Logs</h3>
                            <div className="log-controls">
                                <label>
                                    <input
                                        type="checkbox"
                                        checked={autoScroll}
                                        onChange={(e) => setAutoScroll(e.target.checked)}
                                    />
                                    Auto-scroll
                                </label>
                                <button className="btn btn-sm">Clear</button>
                                <button className="btn btn-sm">Download</button>
                            </div>
                        </div>
                        
                        <div className="log-container">
                            {logs[selectedExecution] && logs[selectedExecution].length > 0 ? (
                                logs[selectedExecution].map((line, index) => renderLogLine(line, index))
                            ) : (
                                <div className="no-logs">
                                    <p>No logs available for this execution</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

window.ExecutionMonitor = ExecutionMonitor;
