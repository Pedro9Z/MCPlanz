const { useState, useEffect } = React;
const WorkflowList = window.WorkflowList;
const WorkflowEditor = window.WorkflowEditor;
const ExecutionMonitor = window.ExecutionMonitor;
const SystemStatus = window.SystemStatus;

const App = () => {
    const [currentView, setCurrentView] = useState('workflows');
    const [selectedWorkflow, setSelectedWorkflow] = useState(null);
    const [workflows, setWorkflows] = useState([]);
    const [systemInfo, setSystemInfo] = useState(null);
    const [executions, setExecutions] = useState({});

    useEffect(() => {
        initializeApp();
    }, []);

    const initializeApp = async () => {
        try {
            // Load system information
            const systemResult = await window.electronAPI.getSystemInfo();
            if (systemResult.success) {
                setSystemInfo(systemResult.data);
            }

            // Load existing workflows
            const workflowsResult = await window.electronAPI.loadWorkflows();
            if (workflowsResult.success) {
                setWorkflows(workflowsResult.data);
            }
        } catch (error) {
            console.error('Failed to initialize app:', error);
        }
    };

    const handleCreateWorkflow = () => {
        setSelectedWorkflow(null);
        setCurrentView('editor');
    };

    const handleEditWorkflow = (workflow) => {
        setSelectedWorkflow(workflow);
        setCurrentView('editor');
    };

    const handleExecuteWorkflow = async (workflow) => {
        try {
            const result = await window.electronAPI.executeWorkflow(workflow);
            if (result.success) {
                setExecutions(prev => ({
                    ...prev,
                    [result.data.executionId]: {
                        id: result.data.executionId,
                        workflow: workflow.name,
                        status: 'running',
                        startTime: new Date(),
                        logs: []
                    }
                }));
                setCurrentView('monitor');
            }
        } catch (error) {
            console.error('Failed to execute workflow:', error);
        }
    };

    const handleSaveWorkflow = async (workflow) => {
        try {
            const result = await window.electronAPI.saveWorkflow(workflow);
            if (result.success) {
                await initializeApp(); // Reload workflows
                setCurrentView('workflows');
            }
        } catch (error) {
            console.error('Failed to save workflow:', error);
        }
    };

    const handleDeleteWorkflow = async (filename) => {
        try {
            const result = await window.electronAPI.deleteWorkflow(filename);
            if (result.success) {
                await initializeApp(); // Reload workflows
            }
        } catch (error) {
            console.error('Failed to delete workflow:', error);
        }
    };

    const handleImportWorkflow = async () => {
        try {
            const result = await window.electronAPI.importWorkflow();
            if (result.success) {
                setSelectedWorkflow(result.data);
                setCurrentView('editor');
            }
        } catch (error) {
            console.error('Failed to import workflow:', error);
        }
    };

    const renderCurrentView = () => {
        switch (currentView) {
            case 'workflows':
                return (
                    <WorkflowList
                        workflows={workflows}
                        onEdit={handleEditWorkflow}
                        onExecute={handleExecuteWorkflow}
                        onDelete={handleDeleteWorkflow}
                        onCreate={handleCreateWorkflow}
                        onImport={handleImportWorkflow}
                    />
                );
            case 'editor':
                return (
                    <WorkflowEditor
                        workflow={selectedWorkflow}
                        onSave={handleSaveWorkflow}
                        onCancel={() => setCurrentView('workflows')}
                        systemInfo={systemInfo}
                    />
                );
            case 'monitor':
                return (
                    <ExecutionMonitor
                        executions={executions}
                        onStop={(executionId) => window.electronAPI.stopWorkflow(executionId)}
                    />
                );
            default:
                return <div>Unknown view</div>;
        }
    };

    return (
        <div className="app">
            <div className="app-header">
                <h1>App Launcher</h1>
                <div className="navigation">
                    <button
                        className={currentView === 'workflows' ? 'active' : ''}
                        onClick={() => setCurrentView('workflows')}
                    >
                        Workflows
                    </button>
                    <button
                        className={currentView === 'monitor' ? 'active' : ''}
                        onClick={() => setCurrentView('monitor')}
                    >
                        Monitor
                    </button>
                </div>
                <SystemStatus systemInfo={systemInfo} />
            </div>
            <div className="app-content">
                {renderCurrentView()}
            </div>
        </div>
    );
};

window.App = App;
