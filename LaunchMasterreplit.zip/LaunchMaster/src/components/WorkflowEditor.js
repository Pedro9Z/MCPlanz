const { useState, useEffect } = React;

const StepItem = ({ step, index, onEdit, onDelete }) => {
    return (
        <div className="step-item">
            <div className="step-header">
                <span className="step-number">{index + 1}</span>
                <span className="step-name">{step.name}</span>
                <div className="step-actions">
                    <button onClick={() => onEdit(index)} className="btn-icon">✏️</button>
                    <button onClick={() => onDelete(index)} className="btn-icon">🗑️</button>
                </div>
            </div>
            <div className="step-body">
                <div className="step-command">
                    <code>{step.command}</code>
                </div>
                {step.description && (
                    <div className="step-description">
                        {step.description}
                    </div>
                )}
            </div>
        </div>
    );
};

const WorkflowEditor = ({ workflow, onSave, onCancel }) => {
    const [workflowForm, setWorkflowForm] = useState({
        name: '',
        description: '',
        mode: 'native',
        image: '',
        ports: [],
        volumes: [],
        environment: {},
        healthcheck: null,
        steps: []
    });

    const [editingStep, setEditingStep] = useState(null);
    const [stepForm, setStepForm] = useState({
        name: '',
        command: '',
        description: '',
        workdir: '.',
        timeout: 0
    });

    useEffect(() => {
        if (workflow) {
            setWorkflowForm({ ...workflow });
        } else {
            // Reset form for new workflow
            setWorkflowForm({
                name: '',
                description: '',
                mode: 'native',
                image: '',
                ports: [],
                volumes: [],
                environment: {},
                healthcheck: null,
                steps: []
            });
        }
    }, [workflow]);

    const handleSave = async () => {
        if (!workflowForm.name || workflowForm.steps.length === 0) {
            alert('Please provide a name and at least one step');
            return;
        }

        try {
            const result = await window.electronAPI.saveWorkflow(workflowForm);
            if (result.success) {
                onSave();
            } else {
                alert('Failed to save workflow: ' + result.error);
            }
        } catch (error) {
            alert('Failed to save workflow: ' + error.message);
        }
    };

    const handleAddStep = () => {
        setStepForm({
            name: '',
            command: '',
            description: '',
            workdir: '.',
            timeout: 0
        });
        setEditingStep('new');
    };

    const handleEditStep = (index) => {
        const step = workflowForm.steps[index];
        setStepForm({ ...step });
        setEditingStep(index);
    };

    const handleSaveStep = () => {
        if (!stepForm.name || !stepForm.command) {
            alert('Please provide a name and command for the step');
            return;
        }

        const newSteps = [...workflowForm.steps];
        
        if (editingStep === 'new') {
            newSteps.push({ ...stepForm });
        } else {
            newSteps[editingStep] = { ...stepForm };
        }

        setWorkflowForm({ ...workflowForm, steps: newSteps });
        setEditingStep(null);
        setStepForm({
            name: '',
            command: '',
            description: '',
            workdir: '.',
            timeout: 0
        });
    };

    const handleDeleteStep = (index) => {
        if (confirm('Are you sure you want to delete this step?')) {
            const newSteps = workflowForm.steps.filter((_, i) => i !== index);
            setWorkflowForm({ ...workflowForm, steps: newSteps });
        }
    };

    const handleAddPort = () => {
        const ports = [...workflowForm.ports];
        ports.push('3000:3000');
        setWorkflowForm({ ...workflowForm, ports });
    };

    const handleUpdatePort = (index, value) => {
        const ports = [...workflowForm.ports];
        ports[index] = value;
        setWorkflowForm({ ...workflowForm, ports });
    };

    const handleRemovePort = (index) => {
        const ports = workflowForm.ports.filter((_, i) => i !== index);
        setWorkflowForm({ ...workflowForm, ports });
    };

    const handleAddVolume = () => {
        const volumes = [...workflowForm.volumes];
        volumes.push('./:/workspace');
        setWorkflowForm({ ...workflowForm, volumes });
    };

    const handleUpdateVolume = (index, value) => {
        const volumes = [...workflowForm.volumes];
        volumes[index] = value;
        setWorkflowForm({ ...workflowForm, volumes });
    };

    const handleRemoveVolume = (index) => {
        const volumes = workflowForm.volumes.filter((_, i) => i !== index);
        setWorkflowForm({ ...workflowForm, volumes });
    };

    const handleAddEnvVar = () => {
        const key = prompt('Environment variable name:');
        if (key) {
            const value = prompt('Environment variable value:');
            setWorkflowForm({
                ...workflowForm,
                environment: { ...workflowForm.environment, [key]: value || '' }
            });
        }
    };

    const handleUpdateEnvVar = (key, value) => {
        setWorkflowForm({
            ...workflowForm,
            environment: { ...workflowForm.environment, [key]: value }
        });
    };

    const handleRemoveEnvVar = (key) => {
        const environment = { ...workflowForm.environment };
        delete environment[key];
        setWorkflowForm({ ...workflowForm, environment });
    };

    const renderModeSpecificFields = () => {
        if (workflowForm.mode === 'container') {
            return (
                <div className="container-config">
                    <h3>Container Configuration</h3>
                    
                    <div className="form-group">
                        <label>Docker Image *</label>
                        <input
                            type="text"
                            value={workflowForm.image}
                            onChange={(e) => setWorkflowForm({ ...workflowForm, image: e.target.value })}
                            placeholder="node:18-alpine"
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label>Port Mappings</label>
                        {workflowForm.ports.map((port, index) => (
                            <div key={index} className="array-item">
                                <input
                                    type="text"
                                    value={port}
                                    onChange={(e) => handleUpdatePort(index, e.target.value)}
                                    placeholder="3000:3000"
                                />
                                <button
                                    type="button"
                                    onClick={() => handleRemovePort(index)}
                                    className="btn-remove"
                                >
                                    Remove
                                </button>
                            </div>
                        ))}
                        <button type="button" onClick={handleAddPort} className="btn btn-secondary">
                            Add Port
                        </button>
                    </div>

                    <div className="form-group">
                        <label>Volume Mounts</label>
                        {workflowForm.volumes.map((volume, index) => (
                            <div key={index} className="array-item">
                                <input
                                    type="text"
                                    value={volume}
                                    onChange={(e) => handleUpdateVolume(index, e.target.value)}
                                    placeholder="./:/workspace"
                                />
                                <button
                                    type="button"
                                    onClick={() => handleRemoveVolume(index)}
                                    className="btn-remove"
                                >
                                    Remove
                                </button>
                            </div>
                        ))}
                        <button type="button" onClick={handleAddVolume} className="btn btn-secondary">
                            Add Volume
                        </button>
                    </div>

                    <div className="form-group">
                        <label>Environment Variables</label>
                        {Object.entries(workflowForm.environment).map(([key, value]) => (
                            <div key={key} className="array-item">
                                <input
                                    type="text"
                                    value={`${key}=${value}`}
                                    onChange={(e) => {
                                        const [newKey, ...valueParts] = e.target.value.split('=');
                                        handleUpdateEnvVar(newKey, valueParts.join('='));
                                    }}
                                    placeholder="NODE_ENV=development"
                                />
                                <button
                                    type="button"
                                    onClick={() => handleRemoveEnvVar(key)}
                                    className="btn-remove"
                                >
                                    Remove
                                </button>
                            </div>
                        ))}
                        <button type="button" onClick={handleAddEnvVar} className="btn btn-secondary">
                            Add Environment Variable
                        </button>
                    </div>
                </div>
            );
        }
        return null;
    };

    return (
        <div className="workflow-editor">
            <div className="editor-header">
                <h2>{workflow ? 'Edit Workflow' : 'Create New Workflow'}</h2>
                <div className="editor-actions">
                    <button onClick={onCancel} className="btn btn-secondary">
                        Cancel
                    </button>
                    <button onClick={handleSave} className="btn btn-primary">
                        Save Workflow
                    </button>
                </div>
            </div>

            <div className="editor-content">
                <div className="basic-config">
                    <h3>Basic Configuration</h3>
                    
                    <div className="form-group">
                        <label>Name *</label>
                        <input
                            type="text"
                            value={workflowForm.name}
                            onChange={(e) => setWorkflowForm({ ...workflowForm, name: e.target.value })}
                            placeholder="My Workflow"
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label>Description</label>
                        <textarea
                            value={workflowForm.description}
                            onChange={(e) => setWorkflowForm({ ...workflowForm, description: e.target.value })}
                            placeholder="Workflow description..."
                            rows="3"
                        />
                    </div>

                    <div className="form-group">
                        <label>Execution Mode *</label>
                        <select
                            value={workflowForm.mode}
                            onChange={(e) => setWorkflowForm({ ...workflowForm, mode: e.target.value })}
                        >
                            <option value="native">Native</option>
                            <option value="container">Container</option>
                        </select>
                    </div>
                </div>

                {renderModeSpecificFields()}

                <div className="steps-config">
                    <h3>Steps</h3>
                    
                    <div className="steps-list">
                        {workflowForm.steps.map((step, index) => (
                            <StepItem
                                key={index}
                                step={step}
                                index={index}
                                onEdit={handleEditStep}
                                onDelete={handleDeleteStep}
                            />
                        ))}
                    </div>

                    <button onClick={handleAddStep} className="btn btn-primary">
                        Add Step
                    </button>

                    {editingStep !== null && (
                        <div className="step-editor">
                            <h4>{editingStep === 'new' ? 'Add New Step' : 'Edit Step'}</h4>
                            <div className="form-group">
                                <label>Step Name *</label>
                                <input
                                    type="text"
                                    value={stepForm.name}
                                    onChange={(e) => setStepForm({ ...stepForm, name: e.target.value })}
                                    placeholder="Install dependencies"
                                />
                            </div>
                            <div className="form-group">
                                <label>Command *</label>
                                <input
                                    type="text"
                                    value={stepForm.command}
                                    onChange={(e) => setStepForm({ ...stepForm, command: e.target.value })}
                                    placeholder="npm install"
                                />
                            </div>
                            <div className="form-group">
                                <label>Description</label>
                                <input
                                    type="text"
                                    value={stepForm.description}
                                    onChange={(e) => setStepForm({ ...stepForm, description: e.target.value })}
                                    placeholder="Step description..."
                                />
                            </div>
                            <div className="form-group">
                                <label>Working Directory</label>
                                <input
                                    type="text"
                                    value={stepForm.workdir}
                                    onChange={(e) => setStepForm({ ...stepForm, workdir: e.target.value })}
                                    placeholder="."
                                />
                            </div>
                            <div className="form-group">
                                <label>Timeout (seconds, 0 = no timeout)</label>
                                <input
                                    type="number"
                                    value={stepForm.timeout}
                                    onChange={(e) => setStepForm({ ...stepForm, timeout: parseInt(e.target.value) })}
                                    min="0"
                                />
                            </div>
                            <div className="step-editor-actions">
                                <button onClick={() => setEditingStep(null)} className="btn btn-secondary">
                                    Cancel
                                </button>
                                <button onClick={handleSaveStep} className="btn btn-primary">
                                    Save Step
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

window.WorkflowEditor = WorkflowEditor;