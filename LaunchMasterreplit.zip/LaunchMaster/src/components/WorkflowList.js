const { useState } = React;

const WorkflowList = ({ workflows, onEdit, onExecute, onDelete, onCreate, onImport }) => {
    const [searchTerm, setSearchTerm] = useState('');

    const filteredWorkflows = workflows.filter(workflow =>
        workflow.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        workflow.description?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const getModeIcon = (mode) => {
        return mode === 'container' ? '🐳' : '⚡';
    };

    const getStatusColor = (workflow) => {
        // Simple validation check
        if (!workflow.steps || workflow.steps.length === 0) {
            return 'error';
        }
        return 'ready';
    };

    return (
        <div className="workflow-list">
            <div className="workflow-list-header">
                <div className="search-container">
                    <input
                        type="text"
                        placeholder="Search workflows..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="search-input"
                    />
                </div>
                <div className="action-buttons">
                    <button onClick={onCreate} className="btn btn-primary">
                        <span>➕</span> Create Workflow
                    </button>
                    <button onClick={onImport} className="btn btn-secondary">
                        <span>📁</span> Import
                    </button>
                </div>
            </div>

            <div className="workflow-grid">
                {filteredWorkflows.length === 0 ? (
                    <div className="empty-state">
                        <h3>No workflows found</h3>
                        <p>Create your first workflow to get started</p>
                        <button onClick={onCreate} className="btn btn-primary">
                            Create Workflow
                        </button>
                    </div>
                ) : (
                    filteredWorkflows.map((workflow, index) => (
                        <div key={index} className={`workflow-card ${getStatusColor(workflow)}`}>
                            <div className="workflow-card-header">
                                <div className="workflow-title">
                                    <span className="mode-icon">{getModeIcon(workflow.mode)}</span>
                                    <h3>{workflow.name}</h3>
                                </div>
                                <div className="workflow-actions">
                                    <button
                                        onClick={() => onEdit(workflow)}
                                        className="btn-icon"
                                        title="Edit workflow"
                                    >
                                        ✏️
                                    </button>
                                    <button
                                        onClick={() => onDelete(workflow.filename)}
                                        className="btn-icon"
                                        title="Delete workflow"
                                    >
                                        🗑️
                                    </button>
                                </div>
                            </div>

                            <div className="workflow-card-body">
                                <p className="workflow-description">
                                    {workflow.description || 'No description available'}
                                </p>
                                
                                <div className="workflow-metadata">
                                    <span className="metadata-item">
                                        Mode: <strong>{workflow.mode}</strong>
                                    </span>
                                    <span className="metadata-item">
                                        Steps: <strong>{workflow.steps?.length || 0}</strong>
                                    </span>
                                    {workflow.healthcheck && (
                                        <span className="metadata-item">
                                            Health check: <strong>✓</strong>
                                        </span>
                                    )}
                                </div>

                                {workflow.mode === 'container' && workflow.image && (
                                    <div className="container-info">
                                        <span className="container-image">
                                            Image: <code>{workflow.image}</code>
                                        </span>
                                    </div>
                                )}
                            </div>

                            <div className="workflow-card-footer">
                                <button
                                    onClick={() => onExecute(workflow)}
                                    className="btn btn-success btn-full"
                                    disabled={getStatusColor(workflow) === 'error'}
                                >
                                    <span>▶️</span> Launch
                                </button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

window.WorkflowList = WorkflowList;
